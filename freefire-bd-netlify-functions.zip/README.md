# FireLink FF BD — Netlify Functions integration

## What is wired
- Frontend calls Netlify Functions, never exposes the API key in browser code.
- `/.netlify/functions/status` reports whether the provider key exists.
- `/.netlify/functions/like` validates numeric UID, allows BD only, and calls the third-party EMON AXC endpoint.
- The app does not claim likes arrived merely because the upstream returned HTTP 200.

## Critical limitations
- EMON AXC is a third-party service and is not verified or endorsed by Garena. Its advertised endpoint and delivery claims have not been independently verified.
- This ZIP does NOT include an API key. I cannot create a provider key or activate your Netlify account for you.
- Real requests will not work until you obtain a valid key from the provider and set it as `EMON_AXC_API_KEY`.
- Check provider pricing, package behavior, terms, and applicable game rules before using it. The fixed `like=100` parameter is treated as the provider's package number, not a guaranteed like count.
- This integration is a starter, not a production abuse-resistant service. Before public launch, add rate limiting, abuse monitoring, and a provider-specific response parser based on verified docs.

## Deploy to Netlify (Functions need a real build/deploy)
1. Upload the extracted project to a GitHub repository.
2. In Netlify, choose Add new site → Import an existing project, connect that repo.
3. Build settings:
   - Build command: leave blank (or `echo "Static site"`)
   - Publish directory: `public`
   - Functions directory: `netlify/functions`
   `netlify.toml` contains these settings too.
4. In Netlify → Site configuration → Environment variables, add:
   - Key: `EMON_AXC_API_KEY`
   - Value: your private API key from the provider
   Do not put the key in `app.js`, `index.html`, GitHub, or chat.
5. Redeploy the site.
6. Check `https://YOUR-SITE/.netlify/functions/status` to see if the key is configured.

## Local development
Install Node.js 18+ and Netlify CLI, set `EMON_AXC_API_KEY` in your local shell, then run:
`netlify dev`

## API reference used
Provider documents `GET /like?key=YOUR_KEY&uid=123456&like=100` at `https://api.freefirelike.com/docs`. This third-party documentation is not an endorsement or guarantee of delivery.
