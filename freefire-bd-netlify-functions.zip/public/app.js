const statusBox = document.getElementById("api-status");
const statusTitle = document.getElementById("api-title");
const statusMessage = document.getElementById("api-message");
const shortStatus = document.getElementById("status-short");
const form = document.getElementById("uid-form");
const uidInput = document.getElementById("uid");
const result = document.getElementById("result");
const button = document.getElementById("check-button");

document.getElementById("year").textContent = new Date().getFullYear();

async function loadStatus() {
  try {
    const res = await fetch("/.netlify/functions/status", { cache: "no-store" });
    const data = await res.json();
    if (data.configured) {
      statusBox.className = "api-status ready";
      statusTitle.textContent = "Provider key configured";
      statusMessage.textContent = "A third-party provider key is configured server-side. Provider availability and delivery are checked when you submit a UID.";
      shortStatus.textContent = "KEY CONFIGURED";
    } else {
      statusBox.className = "api-status";
      statusTitle.textContent = "Real-like API not configured";
      statusMessage.textContent = "Add EMON_AXC_API_KEY in Netlify environment variables. Without a valid provider key, no real-like request can be sent.";
      shortStatus.textContent = "NOT CONFIGURED";
    }
  } catch (_) {
    statusBox.className = "api-status error";
    statusTitle.textContent = "API status unavailable";
    statusMessage.textContent = "Could not contact the Netlify function. Deploy this project with Netlify Functions enabled.";
    shortStatus.textContent = "STATUS ERROR";
  }
}

function showResult(titleText, messageText, kind = "") {
  result.hidden = false;
  result.className = "result " + kind;
  result.replaceChildren();
  const title = document.createElement("strong");
  title.textContent = titleText;
  const p = document.createElement("p");
  p.textContent = messageText;
  result.append(title, p);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const uid = uidInput.value.trim();
  const region = document.getElementById("region").value;
  if (!/^[0-9]{5,20}$/.test(uid)) {
    showResult("Check your UID format", "Enter 5–20 digits only. This checks format, not whether the UID exists.", "error");
    uidInput.focus();
    return;
  }
  if (region !== "BD") {
    showResult("Bangladesh region only", "This integration is configured for the Bangladesh (BD) region only.", "error");
    return;
  }

  button.disabled = true;
  button.innerHTML = "<span>SENDING REQUEST…</span>";
  showResult("Checking provider…", "Your UID is being sent to the configured third-party provider through a server-side function. The API key is not exposed to your browser.");

  try {
    const response = await fetch("/.netlify/functions/like", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ uid, region: "BD", package: 100 })
    });
    const data = await response.json();

    if (response.ok && data.providerAccepted === true) {
      showResult("Provider accepted the request", "Provider response: " + (data.message || "Request accepted") + ". Check the in-game profile and provider history to confirm delivery; acceptance is not independent proof that likes arrived.", "success");
    } else if (response.status === 503 && data.code === "API_KEY_MISSING") {
      showResult("API key not configured", "Add EMON_AXC_API_KEY in Netlify → Site configuration → Environment variables, then redeploy.", "error");
    } else {
      showResult("Request not confirmed", data.message || "The provider did not confirm successful processing. No success is being claimed.", "error");
    }
  } catch (_) {
    showResult("Connection error", "Could not reach the Netlify function. Check deployment logs and try again later.", "error");
  } finally {
    button.disabled = false;
    button.innerHTML = "<span>SEND LIKE REQUEST</span><span class=\"button-arrow\">↗</span>";
    await loadStatus();
  }
});

loadStatus();
