export default async () => {
  const configured = Boolean(process.env.EMON_AXC_API_KEY && process.env.EMON_AXC_API_KEY.trim());
  return new Response(JSON.stringify({
    configured,
    provider: "EMON AXC (third-party; not verified or endorsed by Garena)",
    realLikeDelivery: configured ? "provider-key-present; delivery not guaranteed" : "not-configured"
  }), {
    status: 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff"
    }
  });
};
