const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store",
    "x-content-type-options": "nosniff"
  }
});

export default async (request) => {
  if (request.method !== "POST") {
    return json({ providerAccepted: false, code: "METHOD_NOT_ALLOWED", message: "Use POST." }, 405);
  }

  const key = process.env.EMON_AXC_API_KEY;
  if (!key || !key.trim()) {
    return json({
      providerAccepted: false,
      code: "API_KEY_MISSING",
      message: "No provider API key is configured in Netlify environment variables."
    }, 503);
  }

  let body;
  try {
    body = await request.json();
  } catch {
    return json({ providerAccepted: false, code: "INVALID_JSON", message: "Invalid JSON request body." }, 400);
  }

  const uid = String(body?.uid ?? "").trim();
  const region = String(body?.region ?? "BD").toUpperCase();
  const packageNumber = Number(body?.package ?? 100);

  if (!/^[0-9]{5,20}$/.test(uid)) {
    return json({ providerAccepted: false, code: "INVALID_UID", message: "UID must contain 5–20 digits." }, 400);
  }
  if (region !== "BD") {
    return json({ providerAccepted: false, code: "UNSUPPORTED_REGION", message: "Only Bangladesh (BD) is enabled in this integration." }, 400);
  }
  // Fixed allowlist avoids users choosing arbitrary package values/charges.
  if (packageNumber !== 100) {
    return json({ providerAccepted: false, code: "INVALID_PACKAGE", message: "Only the configured package value is allowed." }, 400);
  }

  const url = new URL("https://api.freefirelike.com/like");
  url.searchParams.set("key", key.trim());
  url.searchParams.set("uid", uid);
  url.searchParams.set("like", String(packageNumber));

  try {
    const upstream = await fetch(url, {
      method: "GET",
      headers: { "accept": "application/json" },
      signal: AbortSignal.timeout(12000)
    });
    const raw = await upstream.text();
    let data;
    try { data = JSON.parse(raw); } catch { data = { providerText: raw.slice(0, 1000) }; }

    // Never equate HTTP 200 alone with likes delivered. Provider-specific success must be explicit.
    const explicitSuccess =
      data?.success === true ||
      data?.providerAccepted === true ||
      String(data?.status ?? "").toLowerCase() === "success";

    const providerMessage = String(data?.message ?? data?.error ?? (explicitSuccess ? "Provider marked request as accepted." : "Provider did not return a recognized success status.")).slice(0, 500);

    return json({
      providerAccepted: Boolean(upstream.ok && explicitSuccess),
      code: upstream.ok ? (explicitSuccess ? "PROVIDER_ACCEPTED" : "PROVIDER_UNCONFIRMED") : "PROVIDER_HTTP_ERROR",
      message: providerMessage,
      httpStatus: upstream.status,
      provider: "EMON AXC",
      note: "A provider response is not independent proof that likes appeared in-game. Confirm in-game and in provider history."
    }, upstream.ok ? (explicitSuccess ? 200 : 502) : 502);
  } catch (error) {
    return json({
      providerAccepted: false,
      code: "PROVIDER_UNREACHABLE",
      message: "The third-party provider could not be reached or timed out. No delivery is confirmed."
    }, 502);
  }
};
